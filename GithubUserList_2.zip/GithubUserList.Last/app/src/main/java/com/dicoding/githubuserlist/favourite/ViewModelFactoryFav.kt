package com.dicoding.githubuserlist.favourite

import android.app.Application
import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import com.dicoding.githubuserlist.data.Repository
import com.dicoding.githubuserlist.detailuser.DetailViewModel
import com.dicoding.githubuserlist.theme.SettingPreferences
import com.dicoding.githubuserlist.theme.ViewModelFactory

class ViewModelFactoryFav(private val application: Application): ViewModelProvider.Factory {
    @Suppress("UNCHECKED_CAST")
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(FavouriteViewModel::class.java)) {
            return FavouriteViewModel(application) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }

//    companion object {
//        @Volatile
//        private var instance: ViewModelFactoryFav? = null
//        fun getInstance(context: Context): ViewModelFactoryFav = instance ?: synchronized(this) {
//            instance ?: ViewModelFactoryFav(Injection.provideRepository(context))
//        }.also { instance = it }
//    }
}