package com.dicoding.githubuserlist.data.database

import androidx.lifecycle.LiveData
import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.dicoding.githubuserlist.data.response.UserItems

@Dao
interface FavouriteUserDAO {
    @Query("SELECT EXISTS(SELECT * FROM FavoriteUser WHERE login = :username)")
    fun isUserFavorited(username: String): Boolean

    @Insert(onConflict = OnConflictStrategy.IGNORE)
    fun insert(user: UserItems)

    @Delete
    fun delete(user: UserItems)

    @Query("SELECT * FROM FavoriteUser")
    fun getAllFavoriteUser(): LiveData<List<UserItems>>
}

//@Dao
//interface FavouriteUserDAO {
//    @Insert(onConflict = OnConflictStrategy.IGNORE)
//     fun insert(favoriteUser: FavouriteUser)

//    @Update
//    suspend fun update(favoriteUser: FavouriteUser)

//    @Delete
//    fun delete(favoriteUser: FavoriteUser)
//
//    @Query("SELECT * from FavouriteUser")
//    fun getAllFavoriteUser(): LiveData<List<FavouriteUser>>
//
//    @Query("SELECT EXISTS(SELECT * FROM FavoriteUser WHERE login = :username)")
//    fun isFavorite(username: String): LiveData<Boolean>

//    @Insert
//    suspend fun addFavorite(favoriteUser: FavouriteUser)
//
//    @Query("SELECT * FROM favorite_user")
//    fun getFavorite(): LiveData<List<FavouriteUser>>
//
//    @Query("SELECT count(*) FROM favorite_user WHERE favorite_user.id = :id")
//    suspend fun checkUser(id: Int): Int
//
//    @Query("DELETE FROM favorite_user WHERE favorite_user.id = :id")
//    suspend fun deleteFavorite(id: Int): Int

//}