package com.dicoding.githubuserlist.favourite

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import androidx.lifecycle.ViewModelProvider
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.dicoding.githubuserlist.adapter.UserListAdapter
import com.dicoding.githubuserlist.data.response.UserItems
import com.dicoding.githubuserlist.databinding.ActivityFavouriteBinding

class FavouriteActivity : AppCompatActivity() {
    private lateinit var binding: ActivityFavouriteBinding
    private var adapter: UserListAdapter = UserListAdapter()
    private lateinit var favouriteViewModel: FavouriteViewModel
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFavouriteBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val layoutManager = LinearLayoutManager(this)
        binding.rvFavourite.layoutManager = LinearLayoutManager(this)
        binding.rvFavourite.adapter = adapter
        val itemDecoration = DividerItemDecoration(this, layoutManager.orientation)
        binding.rvFavourite.addItemDecoration(itemDecoration)

//        val factoryFV: ViewModelFactoryFav = ViewModelFactoryFav.getInstance(this)
        favouriteViewModel = ViewModelProvider(this, ViewModelFactoryFav(application))[FavouriteViewModel::class.java]
        favouriteViewModel.getFavoriteUser().observe(this) {
            adapter.submitList(it)
        }


//
//        adapter = UserListAdapter()
//        adapter.notifyDataSetChanged()
//
//        binding.apply {
//            rvFavourite.setHasFixedSize(true)
//            rvFavourite.layoutManager = LinearLayoutManager(this@FavouriteActivity)
//            rvFavourite.adapter = adapter
//        }
//
//        favouriteViewModel.getFavouriteUser()?.observe(this) { favUsers ->
//            showLoading(false)
//            if (favUsers != null) {
//                val items = favUsers.map { favorit ->
//                    UserItems(
//                        favorit.login,
//                        favorit.id,
//                        favorit.avatarUrl
//                    )
//                }
//                adapter.submitList(items)
//            }
//        }

//        favouriteViewModel.favouriteUser.observe(this) {
//        favouriteViewModel.getFavouriteUser()?.observe(this) {
//            showLoading(false)
//            if (!it.isNullOrEmpty()) {
//                val layoutManager = LinearLayoutManager(this)
//                binding.rvFavourite.layoutManager = layoutManager
//                adapter = UserListAdapter()
//                binding.rvFavourite.adapter = adapter
//            } else {
//                binding.rvFavourite.visibility = View.GONE
//            }
//        }
    }

//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        return when (item.itemId) {
//            android.R.id.home -> {
//                finish() // Handle the back button click (finish the activity)
//                true
//            }
//            else -> super.onOptionsItemSelected(item)
//        }
//    }

}