package com.dicoding.githubuserlist.detailuser

import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.service.autofill.UserData
import android.util.Log
import android.view.MenuItem
import android.view.View
import androidx.annotation.StringRes
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import com.bumptech.glide.Glide
import com.dicoding.githubuserlist.R
import com.dicoding.githubuserlist.adapter.PagerAdapter
import com.dicoding.githubuserlist.adapter.UserListAdapter
import com.dicoding.githubuserlist.data.Repository
import com.dicoding.githubuserlist.data.response.DetailUserResponse
import com.dicoding.githubuserlist.data.response.UserItems
import com.dicoding.githubuserlist.data.response.UserResponse
import com.dicoding.githubuserlist.databinding.ActivityDetailUserBinding
import com.dicoding.githubuserlist.theme.ViewModelFactory
import com.google.android.material.tabs.TabLayoutMediator
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class DetailUserActivity : AppCompatActivity() {
    private lateinit var binding: ActivityDetailUserBinding
//    private var username: String? = null
//    private var Ngecek: Boolean = false
    private lateinit var mRepository: Repository
    private lateinit var dataUser: UserItems
    private lateinit var detailViewModel: DetailViewModel
//    private lateinit var detailUser: DetailUserResponse

    companion object {
        const val EXTRA_ID = "extra_id"
//        const val EXTRA_NAME = "username"
//        const val EXTRA_URL = "extra_url"

        @StringRes
        private val TAB_TITLES = intArrayOf(
            R.string.followers,
            R.string.following
        )
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDetailUserBinding.inflate(layoutInflater)
        setContentView(binding.root)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            dataUser = intent.getParcelableExtra(EXTRA_ID, UserItems::class.java)!!
        } else {
            @Suppress("DEPRECATION")
            dataUser = intent.getParcelableExtra(EXTRA_ID)!!
        }

//        val detailViewModel = ViewModelProvider(this, ViewModelProvider.NewInstanceFactory()).get(DetailViewModel::class.java)

//        val factoryFav: ViewModelFactoryFav = ViewModelFactoryFav.getInstance(this)
        detailViewModel = ViewModelProvider(this, ViewModelFactoryDetail(application))[DetailViewModel::class.java]

        mRepository = Repository(application)

//        username = intent.getStringExtra("username")

        detailViewModel.isLoading.observe(this) {
            showLoading(it)
        }

//        val username = intent.getStringExtra(EXTRA_ID)

        detailViewModel.getDetailUser(dataUser.login)
        detailViewModel.detailUser.observe(this) {
                userData ->
            binding.tvUsername.text = userData.login
            binding.tvName.text = userData.name
            binding.tvFollower.text = "${userData.followers} Followers"
            binding.tvFollowing.text = "${userData.following} Following"
            Glide
                .with(this)
                .load(userData.avatarUrl)
                .into(binding.ivPhoto)

//            setFavourite(userData)
        }

        val pagerAdapter = PagerAdapter(this, dataUser.login)
        binding.viewPager.adapter = pagerAdapter
        TabLayoutMediator(binding.tabs, binding.viewPager) {tab, position ->
            tab.text = resources.getString(TAB_TITLES[position])
        }.attach()

        val fabFav = binding.fabAdd
        var isUserInDatabase = false
        detailViewModel.checkUserFavorite(dataUser.login) { isFav ->
            isUserInDatabase = if (isFav) {
                fabFav.setImageDrawable(ContextCompat.getDrawable(fabFav.context, R.drawable.ic_favourite))
                true
            } else {
                fabFav.setImageDrawable(ContextCompat.getDrawable(fabFav.context, R.drawable.ic_favourite_border))
                false
            }
        }

        fabFav.setOnClickListener {
            if (isUserInDatabase) {
                detailViewModel.deleteFromDb(dataUser)
                fabFav.setImageDrawable(ContextCompat.getDrawable(fabFav.context, R.drawable.ic_favourite_border))
            } else {
                detailViewModel.insertToDb(dataUser)
                fabFav.setImageDrawable(ContextCompat.getDrawable(fabFav.context, R.drawable.ic_favourite))
            }
        }

//        setFavourite()

//        val username = intent.getStringExtra(EXTRA_NAME)
//        val id = intent.getIntExtra(EXTRA_ID, 0)
//        val imgUrl = intent.getStringExtra(EXTRA_URL)

//        binding.fabAdd.setOnClickListener {
//            Log.d("infokan", "cek")
//            CoroutineScope(Dispatchers.IO).launch {
//                val count = detailViewModel.checkUser(id)
//                withContext(Dispatchers.Main) {
//                    if (count != null) {
//                        detailViewModel.deleteFavourite(id)
//                        binding.fabAdd.setImageDrawable(
//                            ContextCompat.getDrawable(
//                                binding.fabAdd.context,
//                                R.drawable.ic_favourite_border
//                            )
//                        )
//                    } else {
//                        if (username != null && imgUrl != null) {
//                            detailViewModel.addFavourite(username, id, imgUrl)
//                            binding.fabAdd.setImageDrawable(
//                                ContextCompat.getDrawable(
//                                    binding.fabAdd.context,
//                                    R.drawable.ic_favourite
//                                )
//                            )
//                        }
//                    }
//                }
//            }
//        }

//        CoroutineScope(Dispatchers.IO).launch {
//            val ivFav = binding.fabAdd
//            val count = detailViewModel.checkUser(id)
//            withContext(Dispatchers.Main) {
//                if (count != null) {
////                    Ngecek = count > 0
//                    ivFav.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            ivFav.context,
//                            R.drawable.ic_favourite
//                        )
//                    )
//                } else {
//                    ivFav.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            ivFav.context,
//                            R.drawable.ic_favourite_border
//                        )
//                    )
//                }
//                // oii chatgpt disini ini diisi apa cokkk ?
//            }
//        }
//
//        binding.fabAdd.setOnClickListener {
//
//        }
    }


//    private fun setFavourite(detailUser: DetailUserResponse) {
//        Log.d("info2", "infosettt")
//        val ivFav = binding.fabAdd
////        detailViewModel.isFavourite(username).observe(this@DetailUserActivity)
////        detailViewModel.isFavourite(detailUser.login)
//
//        detailViewModel.isFavourites(detailUser.login).observe(this)
//        {
//
//            Log.d("info4", it.toString())
//
//            when (it) {
//
//                true -> {
//                    ivFav.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            ivFav.context,
//                            R.drawable.ic_favourite
//                        )
//                    )
//                    ivFav.setOnClickListener {
//                        val user = FavouriteUser(detailUser.login, detailUser.avatarUrl)
//                        detailViewModel.saveFavourite(user)
//
//                        Log.d("info1", "onklik")
//                    }
//                }
//                false -> {
//                    ivFav.setImageDrawable(
//                        ContextCompat.getDrawable(
//                            ivFav.context,
//                            R.drawable.ic_favourite_border
//                        )
//                    )
//                    ivFav.setOnClickListener {
//                        val user = FavouriteUser(detailUser.login, detailUser.avatarUrl)
//                        detailViewModel.deleteFavourite(user)
//                    }
//                }
//
//
//
////                true -> {
////                    ivFav.setImageDrawable(
////                        ContextCompat.getDrawable(
////                            ivFav.context,
////                            R.drawable.ic_favourite
////                        )
////                    )
////                    ivFav.setOnClickListener {
////                        val user = FavouriteUser(detailUser.login, detailUser.avatarUrl)
////                        detailViewModel.deleteFavourite(user)
////                    }
////                }
////                false -> {
////                    ivFav.setImageDrawable(
////                        ContextCompat.getDrawable(
////                            ivFav.context,
////                            R.drawable.ic_favourite_border
////                        )
////                    )
////                    ivFav.setOnClickListener {
////                        val user = FavouriteUser(detailUser.login, detailUser.avatarUrl)
////                        detailViewModel.saveFavourite(user)
////                    }
////                }
//
//
//            }
//        }
//    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            android.R.id.home -> {
                finish() // Handle the back button click (finish the activity)
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showLoading(isLoading: Boolean) {
        if (isLoading) {
            binding.progressBar2.visibility = View.VISIBLE
        } else {
            binding.progressBar2.visibility = View.GONE
        }
    }
}