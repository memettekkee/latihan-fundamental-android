package com.dicoding.githubuserlist.favourite

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.dicoding.githubuserlist.data.Repository
import com.dicoding.githubuserlist.data.database.FavouriteUserDAO
import com.dicoding.githubuserlist.data.database.FavouriteUserDatabase
import com.dicoding.githubuserlist.data.response.UserItems
import com.dicoding.githubuserlist.data.response.UserResponse

class FavouriteViewModel(application: Application) : AndroidViewModel(application) {

//    private var userDAO: FavouriteUserDAO?
//    private var userDB: FavouriteUserDatabase?

    private var repository: Repository

    init {
//        userDB = FavouriteUserDatabase.getDatabase(application)
//        userDAO = userDB?.favoriteUserDao()
        repository = Repository(application)
    }

    fun getFavoriteUser() = repository.getAllFavoriteUser()

//    fun getFavouriteUser(): LiveData<List<FavouriteUser>>? {
//        return userDAO?.getFavorite()
//    }

//    private val _favouriteuser = MediatorLiveData<List<UserItems>>()
//    val favouriteUser: LiveData<List<UserItems>> = _favouriteuser

//   fun getFavoriteUser() : LiveData<List<FavouriteUser>> {
//        val liveData = repository.getFavoriteUser()
//        _favouriteuser.addSource(liveData)
//        { favoriteUserList ->
//            val convertedList = favoriteUserList.map { favoriteUser ->
//                UserItems(favoriteUser.username, favoriteUser.avatarUrl ?: "")
//            }
//            _favouriteuser.value = convertedList
//        }
////        _favouriteuser.value = liveData.observe
//
//        return liveData
//    }
//
//    init {
//        getFavoriteUser()
//    }
}