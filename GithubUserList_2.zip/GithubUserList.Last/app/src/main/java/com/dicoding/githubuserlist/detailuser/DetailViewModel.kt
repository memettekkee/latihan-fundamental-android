package com.dicoding.githubuserlist.detailuser

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MediatorLiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.dicoding.githubuserlist.data.Repository
import com.dicoding.githubuserlist.data.database.FavouriteUserDAO
import com.dicoding.githubuserlist.data.database.FavouriteUserDatabase
import com.dicoding.githubuserlist.data.response.DetailUserResponse
import com.dicoding.githubuserlist.data.response.UserItems
import com.dicoding.githubuserlist.data.response.UserResponse
import com.dicoding.githubuserlist.data.retrofit.ApiConfig
import com.dicoding.githubuserlist.home.UserViewModel
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class DetailViewModel(application: Application) : AndroidViewModel(application) {

    private var repository: Repository

//    private var userDao: FavouriteUserDAO?
//    private var userDB: FavouriteUserDatabase?

    init {
//        userDB = FavouriteUserDatabase.getDatabase(application)
//        userDao = userDB?.favoriteUserDao()
        repository = Repository(application)
    }

    private val _detailuser = MutableLiveData<DetailUserResponse>()
    val detailUser: LiveData<DetailUserResponse> = _detailuser

    private val _isLoading = MutableLiveData<Boolean>()
    val isLoading: LiveData<Boolean> = _isLoading

//    private val _isFavourite = MediatorLiveData<Boolean>()
//    val isFavourite: LiveData<Boolean> = _isFavourite

//    private val _isFavourite = MutableLiveData<Boolean>()
//    val isFavourite: LiveData<Boolean> = _isFavourite

    companion object {
        private const val TAG = "DetailViewModel"
    }

    fun getDetailUser(username: String) {
        _isLoading.value = true
        val client = ApiConfig.getApiService().getGithubUserDetail(username)
        client.enqueue(object : Callback<DetailUserResponse> {
            override fun onResponse(call: Call<DetailUserResponse>, response: Response<DetailUserResponse>) {
                _isLoading.value = false
                if (response.isSuccessful) {
                    val responseBody = response.body()
                    _detailuser.value = responseBody!!
                } else {
                    _isLoading.value = false
                    Log.e(TAG, "onFailure: ${response.message()}")
                }
            }

            override fun onFailure(call: Call<DetailUserResponse>, t: Throwable) {
                _isLoading.value = false
                Log.e(TAG, "onFailure: ${t.message}")
            }
        })
    }

    fun insertToDb(user: UserItems) {
        repository.insert(user)
    }

    fun deleteFromDb(user: UserItems){
        repository.delete(user)
    }

    fun checkUserFavorite(username: String, callback: (Boolean) -> Unit) {
        repository.checkByUsername(username) { isFavorited ->
            callback(isFavorited)
        }
    }

//    fun addFavourite(username: String, id: Int, avatarUrl: String) {
//        CoroutineScope(Dispatchers.IO).launch {
//            var user = FavouriteUser(
//                username,
//                id,
//                avatarUrl
//            )
//            userDao?.addFavorite(user)
//        }
//    }
//
//    suspend fun checkUser(id: Int) = userDao?.checkUser(id)
//
//    fun deleteFavourite(id: Int) {
//        CoroutineScope(Dispatchers.IO).launch {
//            userDao?.deleteFavorite(id)
//        }
//    }

//    fun isFavourites(username: String) : LiveData<Boolean> {
//        val liveData = repository.isFavorite(username)
//        Log.d("info5", "ceks")
////        _isFavourite.addSource(liveData) { result ->
////            Log.d("info3", result.toString())
////            _isFavourite.value = result
////        }
//        return liveData
//    } // disini errornya
//
//    fun saveFavourite(favourite: FavouriteUser) =
//        viewModelScope.launch(Dispatchers.IO) { repository.saveFavorite(favourite)}
//
//    fun deleteFavourite(favourite: FavouriteUser) =
//        viewModelScope.launch(Dispatchers.IO) { repository.delete(favourite)}
}